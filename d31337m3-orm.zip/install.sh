#!/bin/bash
set -e

echo "=== D31337m3 ORM Installer ==="

# Extract archive
if [ -f "d31337m3-orm.tar.gz" ]; then
    echo "Extracting archive..."
    tar -xzf d31337m3-orm.tar.gz
else
    echo "Error: d31337m3-orm.tar.gz not found"
    exit 1
fi

# Install root dependencies
echo "Installing root dependencies..."
npm install

# Install server-api dependencies
echo "Installing server-api dependencies..."
cd apps/server-api
npm install

# Install client-spa dependencies
echo "Installing client-spa dependencies..."
cd ../client-spa
npm install

echo ""
echo "=== Installation Complete ==="
echo ""
echo "To start the application:"
echo "  Option 1: ./start_local.sh"
echo "  Option 2: ./start_servers.sh"
echo ""
echo "For manual start:"
echo "  Terminal 1: cd apps/server-api && npm run dev"
echo "  Terminal 2: cd apps/client-spa && npm run dev"